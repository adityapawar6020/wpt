export default function Welcome()
{
    return(
        <>
        <p>Hello Omkar, from welcome</p>
        <p>Welcome to React, from welcome</p>
        </>
    )
}


export function Greeting()
{
    return (<p>Good Morning, from welcome (greeting)</p>)
}